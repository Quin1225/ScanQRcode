//
//  ScanVC.m
//  CSecard
//
//  Created by Quin on 2018/2/1.
//  Copyright © 2018年 Quin. All rights reserved.
//
//屏幕宽度
#define MainScreenWidth [UIScreen mainScreen].bounds.size.width
//屏幕高度
#define MainScreenHeight [UIScreen mainScreen].bounds.size.height
//状态栏
#define StatusbarHeight [[UIApplication sharedApplication]statusBarFrame].size.height
// 导航栏
#define NavigationbarHeight self.navigationController.navigationBar.frame.size.height
//减去状态栏、导航栏高度
#define MainViewHeight (MainScreenHeight-StatusbarHeight-NavigationbarHeight)

#import "ScanVC.h"
#import "AppDelegate.h"
#import <AVFoundation/AVFoundation.h>
#import "UIViewController+Extension.h"
@interface ScanVC ()<AVCaptureMetadataOutputObjectsDelegate,AVCaptureVideoDataOutputSampleBufferDelegate,UIGestureRecognizerDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate>{
    int num;
    BOOL upOrdown;
    NSTimer * timer;
    CAShapeLayer *cropLayer;
    BOOL setCropRect;
    float i;
    CGFloat _initialPinchZoom;
    BOOL cancelTimer;
}
@property (strong,nonatomic)AVCaptureDevice * device;
@property (strong,nonatomic)AVCaptureDeviceInput * input;
@property (strong,nonatomic)AVCaptureMetadataOutput * output;
@property (strong,nonatomic)AVCaptureSession * session;
@property (strong,nonatomic)AVCaptureVideoPreviewLayer * preview;

@property (nonatomic, strong) UIImageView * line;
@property (weak, nonatomic) IBOutlet UIImageView *ScanImageView;
@property (weak, nonatomic) IBOutlet UIView *photoflashView;
@property (weak, nonatomic) IBOutlet UIButton *photoflashBtn;
@property (weak, nonatomic) IBOutlet UIImageView *photoflashImg;
@property (weak, nonatomic) IBOutlet UILabel *photoflashLabel;


@end

@implementation ScanVC
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    UIInterfaceOrientation currentOrient = [UIApplication  sharedApplication].statusBarOrientation;
    if (currentOrient==UIInterfaceOrientationLandscapeLeft||currentOrient==UIInterfaceOrientationLandscapeRight) {
        NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];//强制竖屏
        [[UIDevice currentDevice]setValue:value forKey:@"orientation"];
    }
    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    delegate.enablePortrait = YES;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    delegate.enablePortrait = NO;
    if (cancelTimer) {
        [timer invalidate];
    }
}
-(void)viewDidLayoutSubviews{
    
    if (MainScreenWidth<MainViewHeight) {
        _ScanImageView.frame=CGRectMake(50, (MainViewHeight-(MainScreenWidth-100))/2, MainScreenWidth-100, MainScreenWidth-100);
        if (setCropRect) {
            return;
        }
        [self setCropRect:_ScanImageView.frame];
    }else{
        _ScanImageView.frame=CGRectMake((MainScreenWidth-(MainViewHeight-100))/2, 50, MainViewHeight-100, MainViewHeight-100);
        if (setCropRect) {
            return;
        }
        [self setCropRect:_ScanImageView.frame];
    }
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configView];
    i=1;//双击放大缩小
    cancelTimer=YES;//是否释放定时器
    [self.view addGestureRecognizer:[[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchDetected:)]];//捏合手势放大缩小
    [self performSelector:@selector(setupCamera) withObject:self afterDelay:0.3];//
}

#pragma mark ui
-(void)configView{
    UIBarButtonItem *buttonitem=[[UIBarButtonItem alloc]initWithTitle:@"相册" style:UIBarButtonItemStylePlain target:self action:@selector(photo)];
    self.navigationItem.rightBarButtonItem=buttonitem;
    self.navigationItem.rightBarButtonItem.tintColor=[UIColor blackColor];
    
    upOrdown = NO;
    num =0;
    _line = [[UIImageView alloc] initWithFrame:CGRectMake(0, 10, _ScanImageView.frame.size.width, 2)];
    _line.image = [UIImage imageNamed:@"line.png"];
    [_ScanImageView addSubview:_line];
    
    timer = [NSTimer scheduledTimerWithTimeInterval:.02 target:self selector:@selector(linemove) userInfo:nil repeats:YES];
}
#pragma mark 扫描线移动
-(void)linemove{
    if (upOrdown == NO) {
        num ++;
        _line.frame = CGRectMake(0, 10+2*num, _ScanImageView.frame.size.width, 2);
        if (2*num >= _ScanImageView.frame.size.height-20) {
            upOrdown = YES;
        }
    }else {
        num --;
        _line.frame = CGRectMake(0, 10+2*num, _ScanImageView.frame.size.width, 2);
        if (num == 0) {
            upOrdown = NO;
        }
    }
}
#pragma mark 四周模糊渲染
- (void)setCropRect:(CGRect)cropRect{
    cropLayer = [[CAShapeLayer alloc] init];
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddRect(path, nil, cropRect);
    CGPathAddRect(path, nil, self.view.bounds);
    
    [cropLayer setFillRule:kCAFillRuleEvenOdd];
    [cropLayer setPath:path];
    [cropLayer setFillColor:[UIColor blackColor].CGColor];
    [cropLayer setOpacity:0.6];
    [cropLayer setNeedsDisplay];
    [self.view.layer addSublayer:cropLayer];
}
#pragma mark 调取相机扫描
- (void)setupCamera
{
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    if (device==nil) {
        [self Alertview_alone:self Alerttitle:nil Alertstring:@"设备没有摄像头" Surename:nil SureYES:nil];
        return;
    }
    NSString *mediaType = AVMediaTypeVideo;
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:mediaType];
    if(authStatus == AVAuthorizationStatusRestricted || authStatus == AVAuthorizationStatusDenied){
        [self Alertview:self Alerttitle:@"温馨提示" Alertstring:@"请在iPhone的“设置”-“隐私”-“相机”功能中，找到“长沙一卡通”打开相机访问权限" Surename:nil Tononame:nil SureYES:^{
            
        } ToNo:nil];
        return;
    }
    // Device
    _device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    
    // Input
    _input = [AVCaptureDeviceInput deviceInputWithDevice:self.device error:nil];
    
    // Output
    _output = [[AVCaptureMetadataOutput alloc]init];
    [_output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    //闪光灯
    AVCaptureVideoDataOutput *lightOutput = [[AVCaptureVideoDataOutput alloc] init];
    [lightOutput setSampleBufferDelegate:self queue:dispatch_get_main_queue()];
    
    //设置扫描区域
    //    [_output setRectOfInterest:_ScanImageView.frame];
    //设置扫描区域
    CGFloat top = ((MainViewHeight-_ScanImageView.frame.size.height)/2)/MainViewHeight;
    CGFloat left = ((MainScreenWidth-_ScanImageView.frame.size.width)/2)/MainScreenWidth;
    CGFloat width = _ScanImageView.frame.size.width/MainScreenWidth;
    CGFloat height = _ScanImageView.frame.size.height/MainViewHeight;
    ///top 与 left 互换  width 与 height 互换
    [_output setRectOfInterest:CGRectMake(top,left, height, width)];
    // Session
    _session = [[AVCaptureSession alloc]init];
    [_session setSessionPreset:AVCaptureSessionPresetHigh];
    if ([_session canAddInput:self.input])
    {
        [_session addInput:self.input];
    }
    
    if ([_session canAddOutput:self.output])
    {
        [_session addOutput:self.output];
        [_session addOutput:lightOutput];
    }
    
    // 条码类型 AVMetadataObjectTypeQRCode
    [_output setMetadataObjectTypes:[NSArray arrayWithObjects:AVMetadataObjectTypeDataMatrixCode,
                                     AVMetadataObjectTypeAztecCode,
                                     AVMetadataObjectTypeQRCode,
                                     AVMetadataObjectTypePDF417Code,
                                     AVMetadataObjectTypeEAN13Code,
                                     AVMetadataObjectTypeEAN8Code,
                                     AVMetadataObjectTypeCode128Code, nil]];
    
    // Preview
    _preview =[AVCaptureVideoPreviewLayer layerWithSession:_session];
    _preview.videoGravity = AVLayerVideoGravityResizeAspectFill;
    _preview.frame =self.view.layer.bounds;
    [self.view.layer insertSublayer:_preview atIndex:0];
    
    // Start
    [_session startRunning];
}
#pragma mark 单击双击
-(void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *touch = [touches anyObject];
    NSInteger count = [touch tapCount];
    if (count == 1) {
        //        [self performSelector:@selector(sigleTapAction) withObject:nil afterDelay:0.3];
    }
    if (count == 2) {
        //取消单击
        //        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(sigleTapAction) object:nil];
        [self doubleTapAction];
    }
}
#pragma mark 捏合手势放大缩小
- (void)pinchDetected:(UIPinchGestureRecognizer*)recogniser
{
    if (!_device)return;
    if (recogniser.state == UIGestureRecognizerStateBegan){
        _initialPinchZoom = _device.videoZoomFactor;
    }
    NSError *error = nil;
    [_device lockForConfiguration:&error];
    if (!error) {
        CGFloat zoomFactor;
        CGFloat scale = recogniser.scale;
        if (scale < 1.0f) {
            zoomFactor = _initialPinchZoom - pow(_device.activeFormat.videoMaxZoomFactor, 1.0f - recogniser.scale);
        }else{
            zoomFactor = _initialPinchZoom + pow(_device.activeFormat.videoMaxZoomFactor, (recogniser.scale - 1.0f) / 2.0f);
        }
        zoomFactor = MIN(10.0f, zoomFactor);
        zoomFactor = MAX(1.0f, zoomFactor);
        _device.videoZoomFactor = zoomFactor;
        [_device unlockForConfiguration];
    }
}
#pragma mark 双击放大缩小
-(void)doubleTapAction{
    if (!_device)return;
    if (i == UIGestureRecognizerStateBegan){
        _initialPinchZoom = _device.videoZoomFactor;
    }
    NSError *error = nil;
    [_device lockForConfiguration:&error];
    if (!error) {
        CGFloat zoomFactor;
        CGFloat scale = i;
        if (scale >= 2.0f) {
            --i;
            zoomFactor = _initialPinchZoom - pow(_device.activeFormat.videoMaxZoomFactor, 1.0f - i);
        }else{
            ++i;
            zoomFactor = _initialPinchZoom + pow(_device.activeFormat.videoMaxZoomFactor, (i - 1.0f) / 2.0f);
        }
        zoomFactor = MIN(10.0f, zoomFactor);
        zoomFactor = MAX(1.0f, zoomFactor);
        _device.videoZoomFactor = zoomFactor;
        [_device unlockForConfiguration];
    }
}
#pragma mark 扫描结果
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection
{
    NSString *stringValue;
    if ([metadataObjects count] >0)
    {
        //停止扫描
        [_session stopRunning];
        [timer setFireDate:[NSDate distantFuture]];
        
        AVMetadataMachineReadableCodeObject * metadataObject = [metadataObjects objectAtIndex:0];
        stringValue = metadataObject.stringValue;
        NSLog(@"扫描结果：%@",stringValue);
        
        NSArray *arry = metadataObject.corners;
        for (id temp in arry) {
            NSLog(@"%@",temp);
        }
        
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"扫描结果" message:stringValue preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            if (_session != nil && timer != nil) {
                [_session startRunning];
                [timer setFireDate:[NSDate date]];
            }
            
        }]];
        [self presentViewController:alert animated:YES completion:nil];
        
    } else {
        NSLog(@"无扫描信息");
        return;
    }
    
}
#pragma mark- 监听亮度显示闪光灯
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection {
    Class captureDeviceClass = NSClassFromString(@"AVCaptureDevice");
    if (captureDeviceClass != nil) {
        CFDictionaryRef metadataDict = CMCopyDictionaryOfAttachments(NULL,sampleBuffer, kCMAttachmentMode_ShouldPropagate);
        NSDictionary *metadata = [[NSMutableDictionary alloc] initWithDictionary:(__bridge NSDictionary*)metadataDict];
        CFRelease(metadataDict);
        NSDictionary *exifMetadata = [[metadata objectForKey:(NSString *)kCGImagePropertyExifDictionary] mutableCopy];
        float brightnessValue = [[exifMetadata objectForKey:(NSString *)kCGImagePropertyExifBrightnessValue] floatValue];
        //        NSLog(@"%f",brightnessValue);
        
        // 根据brightnessValue的值来打开和关闭闪光灯
        AVCaptureDevice * myLightDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
        BOOL result = [myLightDevice hasTorch];// 判断设备是否有闪光灯
        if ((brightnessValue < 0) && result) {// 打开闪光灯
            self.photoflashView.hidden=NO;
            //            [myLightDevice lockForConfiguration:nil];
            //            [myLightDevice setTorchMode: AVCaptureTorchModeOn];//开
            //            [myLightDevice unlockForConfiguration];
            
        }else if((brightnessValue > 0) && result&&self.photoflashBtn.selected==NO) {// 关闭闪光灯
            self.photoflashView.hidden=YES;
            //[myLightDevice lockForConfiguration:nil];
            // [myLightDevice setTorchMode: AVCaptureTorchModeOff];
            //[myLightDevice unlockForConfiguration];
        }
    }
}
#pragma mark 闪光灯打开关闭
- (IBAction)photoflashBtn:(id)sender {
    setCropRect=YES;
    Class captureDeviceClass = NSClassFromString(@"AVCaptureDevice");
    if (captureDeviceClass != nil) {
        AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
        
        if ([device hasTorch] && [device hasFlash]){
            
            [device lockForConfiguration:nil];
            if (device.torchMode==AVCaptureTorchModeOff||device.flashMode==AVCaptureFlashModeOff) {
                [device setTorchMode:AVCaptureTorchModeOn];
                [device setFlashMode:AVCaptureFlashModeOn];
                self.photoflashBtn.selected=YES;
                self.photoflashLabel.text=@"轻点关闭";
            } else {
                [device setTorchMode:AVCaptureTorchModeOff];
                [device setFlashMode:AVCaptureFlashModeOff];
                self.photoflashBtn.selected=NO;
                self.photoflashLabel.text=@"轻点照亮";
            }
            [device unlockForConfiguration];
        }
    }
}
#pragma mark 相册
-(void)photo{
    cancelTimer=NO;
    // 1.判断相册是否可以打开
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) return;
    //停止扫描
    [_session stopRunning];
    [timer setFireDate:[NSDate distantFuture]];
    //调用相册
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc]init];
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePicker.delegate = self;
    //    imagePicker.allowsEditing = YES;//启动编辑功能
    [self presentViewController:imagePicker animated:YES completion:nil];
}
#pragma mark 取消
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:nil];
    if (_session != nil && timer != nil) {
        [_session startRunning];
        [timer setFireDate:[NSDate date]];
    }
    cancelTimer=YES;
}
#pragma mark 从相册读取
// 获取图片后的操作
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    [picker dismissViewControllerAnimated:YES completion:nil];
    NSString *scannedResult = @"无二维码";
    // 设置图片
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    if(image){
        //1. 初始化扫描仪，设置设别类型和识别质量
        CIDetector*detector = [CIDetector detectorOfType:CIDetectorTypeQRCode context:nil options:@{ CIDetectorAccuracy : CIDetectorAccuracyHigh }];
        //2. 扫描获取的特征组
        NSArray *features = [detector featuresInImage:[CIImage imageWithCGImage:image.CGImage]];
        if([features count] > 0){
            //3. 获取扫描结果
            CIQRCodeFeature *feature = [features objectAtIndex:0];
            scannedResult = feature.messageString;
        }
    }
    
    [self Alertview_alone:self Alerttitle:@"扫描结果" Alertstring:scannedResult Surename:nil SureYES:^{
        if (_session != nil && timer != nil) {
            [_session startRunning];
            [timer setFireDate:[NSDate date]];
        }
    }];
    cancelTimer=YES;
    
}
-(void)dealloc{
    NSLog(@"扫描释放");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

