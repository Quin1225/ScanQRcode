//
//  ScanVC.h
//  CSecard
//
//  Created by Quin on 2018/2/1.
//  Copyright © 2018年 Quin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScanVC : UIViewController

@end
