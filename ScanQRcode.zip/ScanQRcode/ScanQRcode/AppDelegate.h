//
//  AppDelegate.h
//  ScanQRcode
//
//  Created by Quin on 2018/3/6.
//  Copyright © 2018年 Quin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property(nonatomic,assign)BOOL enablePortrait;

@end

