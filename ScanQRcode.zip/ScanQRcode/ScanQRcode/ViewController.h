//
//  ViewController.h
//  ScanQRcode
//
//  Created by Quin on 2018/3/6.
//  Copyright © 2018年 Quin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

