
#import "UIViewController+Extension.h"
@implementation UIViewController (Extension)
#pragma mark 警告框
-(void)Alertview:(UIViewController *)viewcontroller Alerttitle:(NSString *)title Alertstring:(NSString *)alertstr Surename:(NSString *)surename Tononame:(NSString *)tononame SureYES:(void(^)(void))yes ToNo:(void(^)(void))no{
    if (surename.length<=0) {
        surename=@"确定";
    }
    if (tononame.length<=0) {
        tononame=@"取消";
    }
//    if (title.length<=0) {
//        title=@"温馨提醒";
//    }
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:alertstr preferredStyle:UIAlertControllerStyleAlert];
    
    [alertController addAction:[UIAlertAction actionWithTitle:surename style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if (yes)
        {
            yes();
        }
    }]];
    [alertController addAction:[UIAlertAction actionWithTitle:tononame style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        if (no)
        {
            no();
        }
    }]];
    
    [viewcontroller presentViewController:alertController animated:YES completion:nil];
}
#pragma mark 警告框(单按钮)
-(void)Alertview_alone:(UIViewController *)viewcontroller Alerttitle:(NSString *)title Alertstring:(NSString *)alertstr Surename:(NSString *)surename SureYES:(void(^)(void))yes{
    if (surename.length<=0) {
        surename=@"确定";
    }
    if (title.length<=0) {
        title=@"温馨提醒";
    }
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:alertstr preferredStyle:UIAlertControllerStyleAlert];
    
    [alertController addAction:[UIAlertAction actionWithTitle:surename style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if (yes)
        {
            yes();
        }
    }]];
    [viewcontroller presentViewController:alertController animated:YES completion:nil];
}
@end
