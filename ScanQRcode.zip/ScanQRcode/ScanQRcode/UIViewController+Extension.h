
#import <UIKit/UIKit.h>

@interface UIViewController (Extension)

//警告框
-(void)Alertview:(UIViewController *)viewcontroller Alerttitle:(NSString *)title Alertstring:(NSString *)alertstr Surename:(NSString *)surename Tononame:(NSString *)tononame SureYES:(void(^)(void))yes ToNo:(void(^)(void))no;
//警告框(单按钮)
-(void)Alertview_alone:(UIViewController *)viewcontroller Alerttitle:(NSString *)title Alertstring:(NSString *)alertstr Surename:(NSString *)surename SureYES:(void(^)(void))yes;
@end
