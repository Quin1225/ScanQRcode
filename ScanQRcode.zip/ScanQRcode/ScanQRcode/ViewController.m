//
//  ViewController.m
//  ScanQRcode
//
//  Created by Quin on 2018/3/6.
//  Copyright © 2018年 Quin. All rights reserved.
//

#import "ViewController.h"
#import "ScanVC.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self toScan];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self toScan];
}
-(void)toScan{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ScanVC *Scanvc = [storyboard instantiateViewControllerWithIdentifier:@"ScanVC"];
    [self.navigationController pushViewController:Scanvc animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
